public class Data {

    char value;
    int prob;

    public Data(char value, int prob){

        this.value = value;
        this.prob = prob;

    }

}
